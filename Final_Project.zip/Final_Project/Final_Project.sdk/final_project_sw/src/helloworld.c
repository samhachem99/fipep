/******************************************************************************
*
* Copyright (C) 2009 - 2014 Xilinx, Inc.  All rights reserved.
*
* Permission is hereby granted, free of charge, to any person obtaining a copy
* of this software and associated documentation files (the "Software"), to deal
* in the Software without restriction, including without limitation the rights
* to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, and to permit persons to whom the Software is
* furnished to do so, subject to the following conditions:
*
* The above copyright notice and this permission notice shall be included in
* all copies or substantial portions of the Software.
*
* Use of the Software is limited solely to applications:
* (a) running on a Xilinx device, or
* (b) that interact with a Xilinx device through a bus or interconnect.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
* IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
* XILINX  BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
* WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF
* OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
* SOFTWARE.
*
* Except as contained in this notice, the name of the Xilinx shall not be used
* in advertising or otherwise to promote the sale, use or other dealings in
* this Software without prior written authorization from Xilinx.
*
******************************************************************************/

/*
 * helloworld.c: simple test application
 *
 * This application configures UART 16550 to baud rate 9600.
 * PS7 UART (Zynq) is not initialized by this application, since
 * bootrom/bsp configures it to baud rate 115200
 *
 * ------------------------------------------------
 * | UART TYPE   BAUD RATE                        |
 * ------------------------------------------------
 *   uartns550   9600
 *   uartlite    Configurable only in HW design
 *   ps7_uart    115200 (configured by bootrom/bsp)
 */

#define __STDC_FORMAT_MACROS
#include <inttypes.h>
#include <stdlib.h>
#include <stdio.h>
#include "platform.h"
#include "ff.h"				/* FAT File System */
#include "malloc.h"
#include "xparameters.h"	/* SDK generated parameters */
#include "xsdps.h"			/* SD device driver */
#include "xil_printf.h"
#include "xil_cache.h"
#include "xil_io.h"
#include "xplatform_info.h"

#define NUM_BINS 40
#define NUM_PULSES 400
#define PEAKTHRESH 26800
#define BRAM_ADDR_BASE 0x40000000


uint16_t data[NUM_PULSES][NUM_BINS];
int bins[NUM_PULSES][NUM_BINS];
int hist[NUM_BINS];

// SD card and file reading objects
static FIL fil;		/* File object */
static FATFS fatfs;
static char *SD_File;

int parse_data(char* filename)
{
	FRESULT Res;
	UINT NumBytesRead;
    SD_File = (char *)filename;

//    xil_printf("opening file\n\r");
	Res = f_open(&fil, SD_File, FA_READ);
	if (Res) {
		xil_printf("ERROR when opening mnist images data file!\n\r");
		return XST_FAILURE;
	} else {
		xil_printf("Opened mnist images data file\n\r");
	}

	Res = f_lseek(&fil, 0);
	if (Res) {
		xil_printf("Cant seek to start\n\r");
		return XST_FAILURE;
	} else {
		xil_printf("Seeked to start\n\r");
	}

	for(size_t j = 0; j < NUM_PULSES; j++) {
		for(size_t i = 0; i < NUM_BINS; i++) {
			uint8_t val8[2];
			Res = f_read(&fil, val8, 1, &NumBytesRead);
			Res = f_read(&fil, val8+1, 1, &NumBytesRead);
			uint16_t val16 = (val8[0] << 8) + val8[1];
			data[j][i] = val16;
		}
	}

	Res = f_close(&fil);
	if (Res) {
		xil_printf("Failed to close images file\n\r");
		return XST_FAILURE;
	} else {
		xil_printf("Closed images file\n\r");
	}

	xil_printf("Returning...\n\r");
	return XST_SUCCESS;
}

int mock_histograming() {
	for(size_t j = 0; j < NUM_PULSES; j++) {
		for(size_t i = 0; i < NUM_BINS; i++) {
			uint16_t past, present, future;
			present = data[j][i];
			if(i == 0)
				past = 0;
			else
				past = data[j][i-1];

			if(i == 39)
				future = 0;
			else
				future = data[j][i+1];

			if((present <= PEAKTHRESH) && (present <= past) && (present <= future))
				bins[j][i] = 1;
			else
				bins[j][i] = 0;
		}
	}

	for(size_t i = 0; i < NUM_BINS; i++)
		hist[i] = 0;


	for(size_t i = 0; i < NUM_BINS; i++) {
		for(size_t j = 0; j < NUM_PULSES; j++) {
			if(bins[j][i])
				hist[i] += 1;
			else
				hist[i] += 0;
		}
	}

	for(size_t i = 0; i < NUM_BINS; i++) {
		printf("%d ", hist[i]);
	}

	printf("\n");


	return XST_SUCCESS;
}

int move_data_to_bram() {
	int offset = 0;
	for(size_t j = 0; j < NUM_PULSES; j++) {
		for(size_t i = 0; i < NUM_BINS; i++) {
			Xil_Out16(BRAM_ADDR_BASE+offset, data[j][i]);
			offset += 2;
		}
	}

	printf("%d\n", offset);

//	Xil_Out16(BRAM_ADDR_BASE, data[0][0]);
//	Xil_Out16(BRAM_ADDR_BASE+2, data[0][1]);
	xil_printf("finished moving data\n\r");
	return XST_SUCCESS;
}

int main()
{
    init_platform();

    FRESULT Res;
	TCHAR *Path = "0:/";
	Res = f_mount(&fatfs, Path, 0);
	if (Res != FR_OK) {
		xil_printf("Failed to open filesystem\n\r");
		return XST_FAILURE;
	} else {
		xil_printf("Mounted card\n\r");
	}

	xil_printf("Parsing bin data\n\r");
	parse_data("speed.bin");

	xil_printf("Printing histogramming for the first pixel\n\r");
	mock_histograming();

	xil_printf("moving data to bram\n\r");
	move_data_to_bram();

	xil_printf("testing data on bram\n\r");
	u16 val = Xil_In16(BRAM_ADDR_BASE+2);
	xil_printf("data read: %x\n\r", val);

    cleanup_platform();
    return 0;
}
